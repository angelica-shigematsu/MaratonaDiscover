const express = require('express')
//criar servidor

const routes = express.Router()
//no ejs como padrão já sabe o views
//const basePath = __dirname + "/views"

const views = __dirname + "/views/"

const profile = {
    name: "Angélica",
    avatar: "https://avatars.githubusercontent.com/u/78798754?v=4",
    "monthly-budget": 3000,
    "days-per-week": 5,
    "hours-per-day": 5,
    "vacation-per-year": 4
}

routes.get('/',(resq,res) => res.render(views + "index"))
routes.get('/job',(resq,res) => res.render(views + "job"))
routes.get('/job/edit',(resq,res) => res.render(views + "job-edit"))
routes.get('/profile',(resq,res) => res.render(views + "profile", {profile}))

//sendFIle vai enviar o html pronto já no ejs usa render
module.exports = routes