//npm init -y
//npm i express
//npm i nodemon
//npm run dev
//npm i ejs reutilizar e programar no html
const express = require('express')//criar o servidor
const server = express()
const routes = require("./routes")

server.set('view engine', 'ejs')

server.use(express.static("public"))

server.use(routes);

server.listen(3000,() => console.log("rodando"))
//3:45